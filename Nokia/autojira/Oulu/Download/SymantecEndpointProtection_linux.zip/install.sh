#!/bin/bash 
if [[ ${0:0:1} != "/" ]] ; then
  CWD="$PWD"/$(dirname "$0")
else
  CWD=$(dirname "$0")
fi
cd "$CWD"

ROOT="${CWD}"
CONFIG="${ROOT}/Configuration"
PACKAGE_DIR="${ROOT}/Repository"
LEGACY_DIR="${ROOT}/Legacy"
SRC_DIR="${ROOT}/src"
SRC_PACKAGE="ap-kernelmodule.tar.bz2"
VAR_SYMC=/var/symantec
ETC_SYMC=/etc/symantec
SAVREPORTER="savreporter"
SYMC_CONF="/etc/Symantec.conf"

LOG=$(dirname ~/sepfl-install.log)/sepfl-install.log
PACKAGE_LIST=(sav \
		savap \
		savap-legacy \
		savui \
		savjlu\
		)
PACKAGE_LIST_X64=(sav \
		savap-x64 \
		savap-x64-legacy \
		savui \
		savjlu\
		)
INSTALL_PKG_LIST="sep\
				  sepap\
				  sepui\
				  sepjlu\
				  "
CONFIG_LIST="setup.ini\
			 setAid.ini\
			 "
IS_INSTALL=0
IS_UNINSTALL=0
IS_PRECHECK=0
PRECHECK_PACKAGE_NAME="all"
#0 check, 1 not check
IS_CHECK_LEGACY_PACKAGE=0

#savfl install configuration: this file will specify which daemon will not start during installation.
INSTALL_CFG="/etc/savfl_install.cfg"

#savfl install pre-check flag.
PRECHECK_CFG=$(dirname ~/SepPrecheck.cfg)/SepPrecheck.cfg

#savfl install data file. Currently it contains java_home found by precheck.
INSTALL_DATA=$(dirname ~/SepInstallData)/SepInstallData


DAEMONS="symcfgd\
		 rtvscand\
		 smcd\
		 "

MSG_AV_INST_BEGIN="Begin installing virus protection component"
MSG_AV_INST_END="Virus protection component installed successfully"
MSG_AV_INST_FAIL="Virus protection component failed to install"
MSG_AP_INST_BEGIN="Begin installing Auto-Protect component"
MSG_AP_INST_END="Auto-Protect component installed successfully"
MSG_AP_INST_FAIL="Auto-Protect component failed to install"
MSG_LEGACY_AP_INST_BEGIN="Begin installing legacy Auto-Protect component"
MSG_LEGACY_AP_INST_END="Legacy Auto-Protect component installed successfully"
MSG_LEGACY_AP_INST_FAIL="Legacy Auto-Protect component failed to install"
MSG_UI_INST_BEGIN="Begin installing GUI component"
MSG_UI_INST_END="GUI component installed successfully"
MSG_UI_INST_FAIL="GUI component failed to install"
MSG_LU_INST_BEGIN="Begin installing LiveUpdate component"
MSG_LU_INST_END="LiveUpdate component installed successfully"
MSG_LU_INST_FAIL="LiveUpdate component failed to install"

MSG_AV_RM_BEGIN="Begin removing virus protection component"
MSG_AV_RM_END="Virus protection component removed successfully"
MSG_AV_RM_FAIL="Virus protection component failed to remove"
MSG_AP_RM_BEGIN="Begin removing Auto-Protect component"
MSG_AP_RM_END="Auto-Protect component removed successfully"
MSG_AP_RM_FAIL="Auto-Protect component failed to remove"
MSG_LEGACY_AP_RM_BEGIN="Begin removing legacy Auto-Protect component"
MSG_LEGACY_AP_RM_END="Legacy Auto-Protect component removed successfully"
MSG_LEGACY_AP_RM_FAIL="Legacy Auto-Protect component failed to remove"
MSG_UI_RM_BEGIN="Begin removing GUI component"
MSG_UI_RM_END="GUI component removed successfully"
MSG_UI_RM_FAIL="GUI component failed to remove"
MSG_LU_RM_BEGIN="Begin removing LiveUpdate component"
MSG_LU_RM_END="LiveUpdate component removed successfully"
MSG_LU_RM_FAIL="LiveUpdate component failed to remove"

beginInst()
{
	local module="$1"
	
	case ${module} in
		sep)	writeLog "${MSG_AV_INST_BEGIN}" ;;
		sepap)	writeLog "${MSG_AP_INST_BEGIN}" ;;
		sepap-legacy)	writeLog "${MSG_LEGACY_AP_INST_BEGIN}" ;;
		sepui)	writeLog "${MSG_UI_INST_BEGIN}" ;;
		sepjlu)	writeLog "${MSG_LU_INST_BEGIN}" ;;
	esac
	
	return 0
}

endInst()
{
	local module="$1"
	
	case ${module} in
		sep)	writeLog "${MSG_AV_INST_END}" ;;
		sepap)	writeLog "${MSG_AP_INST_END}" ;;
		sepap-legacy)	writeLog "${MSG_LEGACY_AP_INST_END}" ;;
		sepui)	writeLog "${MSG_UI_INST_END}" ;;
		sepjlu)	writeLog "${MSG_LU_INST_END}" ;;
	esac

	return 0
}

failInst()
{
	local module="$1"
	local err="$2"

	case ${module} in
		sep)	writeLog "${MSG_AV_INST_FAIL}, with error: ${err}" ;;
		sepap)	writeLog "${MSG_AP_INST_FAIL}, with error: ${err}" ;;
		sepap-legacy)	writeLog "${MSG_LEGACY_AP_INST_FAIL}, with error: ${err}" ;;
		sepui)	writeLog "${MSG_UI_INST_FAIL}, with error: ${err}" ;;
		sepjlu)	writeLog "${MSG_LU_INST_FAIL}, with error: ${err}" ;;
	
	esac

	return 0
}

beginRm()
{
	local module="$1"
	
	case ${module} in
		sav)	writeLog "${MSG_AV_RM_BEGIN}" ;;
		savap)	writeLog "${MSG_AP_RM_BEGIN}" ;;
		savap-x64)	writeLog "${MSG_AP_RM_BEGIN}" ;;
		savap-legacy)	writeLog "${MSG_LEGACY_AP_RM_BEGIN}" ;;
		savap-x64-legacy)	writeLog "${MSG_LEGACY_AP_RM_BEGIN}" ;;
		savui)	writeLog "${MSG_UI_RM_BEGIN}" ;;
		savjlu)	writeLog "${MSG_LU_RM_BEGIN}" ;;
	
	esac
	
	return 0
}

endRm()
{
	local module="$1"

	case ${module} in
		sav)	writeLog "${MSG_AV_RM_END}" ;;
		savap)	writeLog "${MSG_AP_RM_END}" ;;
		savap-x64)	writeLog "${MSG_AP_RM_END}" ;;
		savap-legacy)	writeLog "${MSG_LEGACY_AP_RM_END}" ;;
		savap-x64-legacy)	writeLog "${MSG_LEGACY_AP_RM_END}" ;;
		savui)	writeLog "${MSG_UI_RM_END}" ;;
		savjlu)	writeLog "${MSG_LU_RM_END}" ;;

	esac
	
	return 0
}

failRm()
{
	local module="$1"
	local err="$2"

	case ${module} in
		sav)	writeLog "${MSG_AV_RM_FAIL}, with error: ${err}" ;;
		savap)	writeLog "${MSG_AP_RM_FAIL}, with error: ${err}" ;;
		savap-x64)	writeLog "${MSG_AP_RM_FAIL}, with error: ${err}" ;;
		savap-legacy)	writeLog "${MSG_LEGACY_AP_RM_FAIL}, with error: ${err}" ;;
		savap-x64-legacy)	writeLog "${MSG_LEGACY_AP_RM_FAIL}, with error: ${err}" ;;
		savui)	writeLog "${MSG_UI_RM_FAIL}, with error: ${err}" ;;
		savjlu)	writeLog "${MSG_LU_RM_FAIL}, with error: ${err}" ;;

	esac
	
	return 0
}

IsRpmSupported()
{
	which rpm > /dev/null 2>&1
	if [ ! 0 -eq $? ] ; then
		return 0
	fi
	
	rpm -qa | grep rpm > /dev/null 2>&1

	if [ 0 -eq $? ]; then
		return 1
	fi

	return 0
}

IsPlatformX64()
{
	uname -m | grep i686 > /dev/null 2>&1
	if [ 0 -eq $? ]; then
		return 0
	fi

	return 1
}

writeLog()
{
    echo -e "$1" 2>&1 
    echo -e "$(date): $1" 2>&1 >> ${LOG}
    return 0
}

#$1 current java version
#java version >=1.5
#@return 1 for valid, 0 for invalid.
javaVersionCheck()
{
	local ver="$1"
	if [ "" = "$ver" ] ; then
		echo "version is empty" >> ${LOG}
		return 0
	fi

	local maj=$(echo $ver | awk -F'.' '{print $1}'|sed 's/\"//g')
	local min=$(echo $ver | awk -F'.' '{print $2}'|sed 's/\"//g')

	if [ "" = "$maj" -o "" = "$min" ] ; then
		echo "maj:${maj} or min:${min} is empty" >> ${LOG}
		return 0
	fi

	if [ $maj -gt 1 ] ; then
		return 1
	elif [ $maj -lt 1 ] ; then
		return 0
	else
		if [ $min -ge 5 ] ; then
			return 1
		else
			return 0
		fi
	fi
}

#$1 java version string. 'java -version'
#return 0 for success, 1 for not.
sunJavaCheck()
{
	local ver="$1"
	local checkCount=0
	
	if [ -z "$ver" ] ; then 
		return 1
	fi

	#check whether it is ibm java.
	checkCount=$(echo $ver | grep -c -i "ibm")
	if [ $checkCount -ge 1 ] ; then
		return 1
	fi

	#check whether it is openjdk.
	checkCount=$(echo $ver | grep -c -i "openjdk")
	if [ $checkCount -ge 1 ] ; then
		return 1
	fi

	#check whether it is sun java >=1.6
	checkCount=$(echo $ver | grep -c -e "Java(TM)[ ]*[eEsS]E")
	if [ $checkCount -ge 1 ] ; then
		return 0
	fi

	local javatm=$(echo $ver | grep "Java(TM)")
	if [ -z "$javatm" ] ; then
		return 1
	fi
	
	# it is sun java 1.5	 
	return 0
}

# $1: full java path such as /usr/bin/java
# return: 0 for succeess. 1 for not superuser, 2 for not sun java, 3 for version < 1.5, 4 for unlimited jce, 5 for other.
javaCheck()
{
	local JNAME="$1"
	
	if [ -z "$JNAME" -o  ! -e "$JNAME" ] ; then
		echo "$JNAME doesn't exist." >> ${LOG}
		return 5
	fi
	# check the owner of the java.
	local owner=$(stat -c --format="%u" $JNAME | awk -F'=' '{print $2}' 2>>${LOG})
	if [ ! 0 -eq $owner ] ; then
		echo "The owner of $JNAME is: $owner, it is not superuser." >> ${LOG}
		return 1
	fi
	# check whether it is sun java.
	if ! sunJavaCheck "$($JNAME -version 2>&1)" ; then
		echo "$JNAME is not sun java, skip it." >> ${LOG}
		return 2
	fi
	# check whether version of java >=1.5
	# get the version of java.
	JVER=$($JNAME -version 2>&1 | grep "java version" | awk -F' ' '{print $3}')

	if  javaVersionCheck "$JVER" ; then
		echo "$JNAME with version $JVER is not a required version." >> ${LOG}
		return 3
	fi

	# check JCE unlimited libraries
	# jlu needs 256-bit encryption key.
	if ! JCEUnlimitedlibCheck "$JNAME" ; then
		echo "$JNAME: Java Cryptography Extension (JCE) Unlimited Strength Jurisdiction Policy Files are not installed. Please download and update them." >> ${LOG}
		return 4
	fi
	return 0
}

findJava()
{
	# If /etc/Symantec.conf exists, we need to check that java to speed up the searching process.
	local symc_conf_java_home=""
	if [ -f "${SYMC_CONF}" ] ; then
		echo "${SYMC_CONF} exists, need to check JAVA_HOME in it firstly." >> ${LOG}
		symc_conf_java_home=$(cat "${SYMC_CONF}"  | awk -F'=' '$1=="JAVA_HOME"{print $2}')
		if [ "${symc_conf_java_home}" != "" ] ; then
			echo "found ${symc_conf_java_home} in ${SYMC_CONF}, check it." >> ${LOG}
			javaCheck "${symc_conf_java_home}/java"
			if [ 0 -eq $? ] ; then
				echo "found java ${symc_conf_java_home}/java" >> ${LOG}
				JAVA="${symc_conf_java_home}/java"
				return 0
			elif [ 4 -eq $? ] ; then
				 writeLog "Java Cryptography Extension (JCE) Unlimited Strength Jurisdiction Policy Files of ${symc_conf_java_home}/java are not installed. Please download and update them."
			fi
				
		fi
	fi

	# Try and find a java, searching in likely places early
	echo "Searching /usr/java for java..." >> ${LOG}
	JLIST=`find /usr/java -follow -type f -name java 2>> ${LOG} | grep 'bin/java'`
	if [ "$JLIST" =  "" ] ; then
		echo "Searching /usr/local for java..." >> ${LOG}
		JLIST=`find /usr/local -follow -type f -name java 2>> ${LOG} | grep 'bin/java'`
		if [ "$JLIST" =  "" ] ; then
		echo "Searching /usr/lib for java..." >> ${LOG}
	      JLIST=`find /usr/lib -follow -type f -name java 2>> ${LOG} | grep 'bin/java'`
		  if [ "$JLIST" =  "" ] ; then
	        echo "Searching /opt for java..." >> ${LOG}
		    JLIST=`find /opt -follow -type f -name java 2>> ${LOG} | grep 'bin/java'`
			if [ "$JLIST" =  "" ] ; then
	          echo "Searching /usr for java..." >> ${LOG}
		      JLIST=`find /usr -follow -type f -name java 2>> ${LOG} | grep 'bin/java'`
	        fi
		  fi
	    fi
	fi

	# If we think we have found java, ask for the version and search for
	# a valid response as some small sanity check that we really do have it
	if [ "$JLIST" != "" ] ; then
		# We may get back multiple results from find
	    for JNAME in $JLIST
		do
			echo $JNAME >> ${LOG}
			# the java recorded in /etc/Symantec.conf has already been checked.
			if [ "$JNAME" = "${symc_conf_java_home}" ] ; then
				continue
			fi

			if [ "$JAVA" = "" ] ; then
				javaCheck "$JNAME"
				if [ 0 -eq $? ] ; then
					echo "found java: $JNAME" >> ${LOG}
					JAVA="$JNAME"
					return 0
				elif [ 4 -eq $? ] ; then
					 writeLog "Java Cryptography Extension (JCE) Unlimited Strength Jurisdiction Policy Files of $JNAME are not installed. Please download and update them."
				fi
			fi
		done
	fi

	return 1
}

glibcCheck()
{
	chmod a+x "${curdir}/precheckglibc" >/dev/null 2>&1
	LC_ALL="C" ldd "${curdir}/precheckglibc" >/dev/null 2>&1
	if [ $? = 0 ] ; then
		LC_ALL="C" ldd "${curdir}/precheckglibc" 2>&1 | grep "not found" >/dev/null 2>&1
		if [ $? = 0 ] ; then
			return 1
		else
			return 0
		fi
	else
		return 1
	fi
}

X11Check()
{
	chmod a+x "${curdir}/precheckX11" >/dev/null 2>&1
	LC_ALL="C" ldd "${curdir}/precheckX11" >/dev/null 2>&1
	if [ $? = 0 ] ; then
		LC_ALL="C" ldd "${curdir}/precheckX11" 2>&1 | grep "not found" >/dev/null 2>&1
		if [ $? = 0 ] ; then
			return 1
		else
			return 0
		fi
	else
		return 1
	fi
}

# $1: full java path such as /usr/bin/java.
# Return: 0 for success, otherwise for failure.
JCEUnlimitedlibCheck()
{
	local JAVA_CHK="$1"
	${JAVA_CHK} -classpath "${curdir}/" JCEUnlimitedlibCheck >/dev/null 2>&1
	return $?
}

#$1: string which may contains whitespaces. $1 must not be empty.
#return: 1 if contains whitespace, 0 if not. if $1 is empty, just return 0.
checkWhitespace()
{
	local str="$1"

	if [ -z "$str" ] ; then
		return 0
	fi

	local truncstr=$(echo "$str" | tr -cd "[\ \n\t]")

	if [ ! -z "$truncstr" ] ; then
		return 1
	fi

	return 0
}

#check whether current env meets with the requirement for all packages or specified package.
preCheckEnv()
{
	local fail=0
	local subret=0
	local packagename=$1
        local prefix="$2"

	writeLog "Performing pre-check..."

	if [ "" = "${curdir}" ] ; then
		writeLog "Error:		Please export curdir='the current folder' and run install again."
		return 1
	fi

	if [ ${packagename} = "all" ] ; then
                #pre-check for --prefix folder
                checkWhitespace "${prefix}"
                subret=$?
                if [ $subret -ne 0 ] ; then
			writeLog "The \"--prefix\" path \"${prefix}\" contains whitespace which are not permitted. Please use another path which doesn't contain whitespace and try again."
			fail=1
		fi

		#pre-check for all packages

		#first check java for jlu usage.
		#jlu needs sun java and version >= 1.5
		findJava
		subret=$?

		if [ $subret -ne 0 ] ; then
			writeLog "Error:		Installation requires Oracle Java 1.5 or later whose owner is superuser. Please install the correct version with superuser and Java Cryptography Extension (JCE) Unlimited Strength Jurisdiction Policy Files, and try again."
			fail=1
		fi

		#third check glibc.i686 in X64 platform
		IsPlatformX64
		if [ $? -eq 1 ] ; then
			glibcCheck
			subret=$?

			if [ $subret -ne 0 ] ; then
				writeLog "Error:		Installation requires 32bits glibc library. Please install it and try again."
				fail=1
			fi
		fi

		#fourth check libX11 package
		#only show a waning to end user
		X11Check
		subret=$?

		if [ $subret -ne 0 ] ; then
			writeLog "Warning:	X11 libraries are missing, GUI component will not be installed!"
		fi

		if [ $fail -eq 0 ] ; then
			echo "yes" > "${PRECHECK_CFG}"
			if [ -f "${INSTALL_DATA}" ] ; then
				rm -f "${INSTALL_DATA}" >> ${LOG} 2>&1
			fi
			echo "JAVA_HOME=$JAVA" >> "${INSTALL_DATA}"
			writeLog "Pre-check succeeded"
		fi
	else
		#pre-check for specified packages

		if [ -f "${PRECHECK_CFG}" ] ; then
			#check libX11 for savui package even the PRECHECK_CFG file exist
			#the rpm method will check it automatically
			#but it is hard to specify the dependence in deb because the package name is different in different distribution
			if [ ${packagename} = "savui" ] ; then
				X11Check
				subret=$?

				if [ $subret -ne 0 ] ; then
					writeLog "Error:	Installation GUI component requires X11 libraries. Please install them and try again."
					fail=1
				fi
			fi

			if [ $fail -eq 0 ] ; then
				echo "Found ${PRECHECK_CFG}, no need to perform pre-check" >> ${LOG}
				writeLog "Pre-check is successful"
			fi
		else
                        #pre-check for --prefix folder
                        checkWhitespace "${prefix}"
                        subret=$?
                        if [ $subret -ne 0 ] ; then
        			writeLog "The \"--prefix\" path \"${prefix}\" contains whitespace which are not permitted. Please use another path which doesn't contain whitespace and try again."
        			fail=1
	        	fi

			#first check java for jlu usage.
			#jlu needs sun java and version >= 1.5
			findJava
			subret=$?

			if [ $subret -ne 0 ] ; then
				writeLog "Error:	Installation requires Oracle Java 1.5 or later whose owner is superuser. Please install the correct version with superuser and Java Cryptography Extension (JCE) Unlimited Strength Jurisdiction Policy Files, and try again."
				fail=1
			fi

			#third check glibc.i686 in X64 platform
			IsPlatformX64
			if [ $? -eq 1 ] ; then
				glibcCheck
				subret=$?

				if [ $subret -ne 0 ] ; then
					writeLog "Error:	Installation requires 32bits glibc library. Please install it and try again."
					fail=1
				fi
			fi

			#fourth check libX11 for savui package
			#the rpm method will check it automatically
			#but it is hard to specify the dependence in deb because the package name is different in different distribution
			if [ ${packagename} = "savui" ] ; then
				X11Check
				subret=$?

				if [ $subret -ne 0 ] ; then
					writeLog "Error:	Installation GUI component requires X11 libraries. Please install them and try again."
					fail=1
				fi
			fi
			
			if [ $fail -eq 0 ] ; then
				writeLog "Pre-check succeeded"
				if [ -f "${INSTALL_DATA}" ] ; then
					rm -f "${INSTALL_DATA}" >> ${LOG} 2>&1
				fi
				echo "JAVA_HOME=$JAVA" >> "${INSTALL_DATA}"
			fi
		fi
	fi

	return $fail
}

#$1 package name to check such as 'sav'
#return 1 for upgrade.
checkUpgrade()
{
	local name="$1"
	if [ ! -f "${INSTALL_CFG}" ] ; then
		echo "${INSTALL_CFG} doesn't exist." >> ${LOG}
		return 0
	fi

	upgrade=$(cat "${INSTALL_CFG}" | grep -c upgrade_${name})

	if [ 0 -eq $upgrade ] ; then
		echo "cannot find upgrade_${name} at ${INSTALL_CFG}" >> ${LOG}
		return 0
	fi

	return 1
}

#$1 "/etc/symantec/Sylink.xml"
#$2 "/Configuration/sylink.xml" under package media.
#return 1 for copy, 0 for doesn't.
checkCopySylink()
{
	local etc_sylink="$1"
	local pkg_sylink="$2"

	if [ ! -f "${pkg_sylink}" ] ; then
		echo "'${pkg_sylink}' doesn't exist." >> ${LOG}
		return 0
	fi

	#if "/etc/symantec" doesn't contain Sylink.xml, need copy it.
	if [ ! -f "${etc_sylink}" ] ; then
		echo "'${etc_sylink}' doesn't exist, need copy it" >> ${LOG}
		return 1
	fi

	#if sylink.xml in package contains server list, copy it to replace current one.
	servers=$(cat "${pkg_sylink}" | grep -c "</ServerList>")

	if [ 0 -eq ${servers} ] ; then
		echo "'${pkg_sylink}' doesn't contain any server." >> ${LOG}
		return 0
	fi

	echo "'${pkg_sylink}' contains server." >> ${LOG}
	
	echo "Existing communication settings file will be replaced." >> ${LOG}
	
	return 1
}

#$1 from_build
#$2 to_build
CopyCfg()
{
	if [ ! -d ${ETC_SYMC} ] ; then
		mkdir -p ${ETC_SYMC}
	fi
	
	if [ ! -d ${VAR_SYMC} ] ; then
		mkdir -p ${VAR_SYMC}
	fi

	
	#copy setup.ini and setAid.ini
	local from_build="$1"
	local to_build="$2"
	isNewBuild "${from_build}" "${to_build}"
	local isnewer=$?
	if [ $isnewer -eq 1 ] ; then
		echo "${to_build} is newer than ${from_build}, need to copy setup.ini & setAid.ini" >> ${LOG}
		for cfg in ${CONFIG_LIST}
		do
			local src=${CONFIG}/${cfg}
			local dest=${ETC_SYMC}/${cfg}
			if [ -f "$src" ] ; then
				cp -f "$src" "$dest" >> ${LOG} 2>&1
				if [ 0 -eq $? ] ; then
					echo "Succeed to copy $src to $dest" >> ${LOG}
				fi
			fi

		done
	fi


	#copy sylink.xml
	local etc_sylink="${ETC_SYMC}/sylink.xml"
	local pkg_sylink=${CONFIG}/sylink.xml

	checkCopySylink "${etc_sylink}" "${pkg_sylink}"

	local replace=$?

	if [ 1 -eq $replace ] ; then
		cp -f "${pkg_sylink}" "${etc_sylink}" >> ${LOG} 2>&1
		if [ ! 0 -eq $? ] ; then
			writeLog "Failed to copy '${pkg_sylink}' to '${etc_sylink}', err: $?"
			return 1
		fi
		echo  "Succeed to copy '${pkg_sylink}' to '${etc_sylink}'." >> ${LOG}

		#copy serdef.dat
		local serdef=${CONFIG}/serdef.dat
		local profile=${VAR_SYMC}/serdef.dat

		if [ -f "$serdef" ] ; then
			cp -f "$serdef" "$profile" >> ${LOG} 2>&1
			if [ 0 -eq $? ] ; then
				echo "Succeed to copy $serdef to $profile" >> ${LOG}
			fi
		fi

		#copy sep.slf or sep_NE.slf
		local sepslf=${CONFIG}/sep.slf
		local sepNEslf=${CONFIG}/sep_NE.slf
		local targetslf=${ETC_SYMC}/sep.slf

		if [ -f "$sepslf" ] ; then
			cp -f "$sepslf" "$targetslf" >> ${LOG} 2>&1
			if [ 0 -eq $? ] ; then
				echo "Succeed to copy $sepslf to $targetslf" >> ${LOG}
			fi
		else
			if [ -f "$sepNEslf" ] ; then
				cp -f "$sepNEslf" "$targetslf" >> ${LOG} 2>&1
				if [ 0 -eq $? ] ; then
					echo "Succeed to copy $sepNEslf to $targetslf" >> ${LOG}
				fi
			fi
		fi

		return 0
	fi

	echo "No need to replace configuration files." >> ${LOG}

	return 0
}

#we will not start symcfgd, rtvscand & smcd during install.
#after install, we will start symcfgd, rtvscand & smcd.
#by doing this, it will speed up the installation process.
disableDaemon()
{
#first remove the old install configuration file if it exists.
	rm -f ${INSTALL_CFG} >> ${LOG} 2>&1
	for daemon in ${DAEMONS}
	do
		echo "${daemon}_enable=0" >> ${INSTALL_CFG}
		if [ -f /etc/init.d/${daemon} ] ; then
			/etc/init.d/${daemon} stop >> ${LOG} 2>&1
		fi
	done
}

isprecompilesymevreloaded()
{
	local symev=$(/sbin/lsmod | grep -e "^symev" | awk -F' ' '{print $1}' | sed -e 's/_/\-/g' -e 's/\./-/g')
	if [ "" = "$symev" ] ; then
		return 1 #no driver found.
	fi

	echo ${symev} | grep -e "^symev-custom" > /dev/null 2>&1
	if [ $? -eq 0 ] ; then
		return 1 #no pre-compiled driver found.
	fi

	local symc_dir=$(cat /etc/Symantec.conf | grep BaseDir | awk -F'=' '{print $2}')
	local ap_dir="${symc_dir}/autoprotect"
	pushd ${ap_dir} > /dev/null 2>&1
	local apfiles=$(ls symev* | xargs | sed -e 's/\.ko//g' -e 's/\./-/g' -e 's/_/-/g')
	for file in $apfiles
	do
		if [ "$file" = "${symev}" ] ; then
			echo "found ${symev}" >> ${LOG}
			popd > /dev/null 2>&1
			return 0
		fi
	done
	popd > /dev/null 2>&1
	
	echo "Cannot found ${symev}.ko" >> ${LOG}
	return 1
}


## o/p of ls <dirname>/<regx>* is of the following form:
## - each regular-file on a separte line.
## - each directory-file on a separate line with ':' character appended at the end of the directory name.
rm_prev_kmod_dirs()
{
	local srcdir="$1"
	[ ! -d "$srcdir" ] && return

	local adirlist=( $(ls -d "$srcdir"/ap-kernelmodule-* 2>/dev/null | tr ":" " " ) )
	local acntdirlist="${#adirlist[@]}"
	let "acntdirlist += 0"

	for (( i = 0; i < acntdirlist; i++ )) ; do
		[ -d "${adirlist["$i"]}" ] && rm -fr "${adirlist["$i"]}"
	done
}

compilekernelmodules()
{
	local err=0
	writeLog "Pre-compiled Auto-Protect kernel modules are not loaded yet, need compile them from source code"
	pushd ${SRC_DIR} > /dev/null 2>&1
	rm_prev_kmod_dirs "$PWD"
	if [ -e ${SRC_PACKAGE} ] ; then
		tar -jxvf ${SRC_PACKAGE} >> ${LOG} 2>&1
		err=$?
		if [ ${err} -eq 0 ] ; then
			pushd `ls -d ap-kernelmodule-*` > /dev/null 2>&1
			./build.sh >> /dev/null 2>&1
			err=$?
			if [ ${err} -eq 0 ] ; then
				writeLog "Build Auto-Protect kernel modules from source code successfully"
			else
				writeLog "Build Auto-Protect kernel modules from source code failed with error: ${err}"
			fi
			popd > /dev/null 2>&1
		else
			writeLog "Fail to extract Auto-Protect source code package with error: ${err}"
		fi
	else
		writeLog "Auto-Protect source code package does not exist"
	fi
	popd > /dev/null 2>&1
}

enableDaemon()
{
#enable autoprotect.
	if [ -f /etc/init.d/autoprotect ] ; then
		/etc/init.d/autoprotect start >> ${LOG} 2>&1

		if [ ${IS_CHECK_LEGACY_PACKAGE} -eq 0 ] ; then
			echo "check whether need to install legacy package." >> ${LOG} 2>&1
		else
			echo "check whether need to compile the kernel modules from source code." >> ${LOG} 2>&1
		fi

		isprecompilesymevreloaded
		if [ $? -eq 1 ] ; then
			if [ ${IS_CHECK_LEGACY_PACKAGE} -eq 0 ] ; then 
				echo "driver is not loaded yet, need legacy kernel package" >> ${LOG}
				local x64=0
				export curdir="${PACKAGE_DIR}"
				IsPlatformX64
				if [ $? -eq 1 ] ; then
					x64=1
				fi
				IsRpmSupported
				if [ $? -eq 1 ] ; then
					#do not uninstall sepap(-x64) package when fail to load AP modules

					beginInst "sepap-legacy"

					local pkg
					if [ $x64 -eq 1 ] ; then
						pkg="${LEGACY_DIR}/sepap-legacy-x86_64.rpm"
					else
						pkg="${LEGACY_DIR}/sepap-legacy.rpm"
					fi

					local doubleref=0
					rpm -qpi "${pkg}" 2>/dev/null | grep 'Vendor: Symantec Corporation' > /dev/null 2>&1
					if [ ! 0 -eq $? ] ; then
						rpm -qpi "\"${pkg}\"" 2>/dev/null | grep 'Vendor: Symantec Corporation' > /dev/null 2>&1
						if [ 0 -eq $? ] ; then
							doubleref=1
						fi
					fi

					if [ "${PREFIX}" != "" ] ; then
						if [ 1 -eq $doubleref ] ; then
							rpm -Uvh "--prefix=${PREFIX}" "\"${pkg}\"" 2>>"${LOG}"
						else
							rpm -Uvh "--prefix=${PREFIX}" "${pkg}" 2>>"${LOG}"
						fi
					else
						if [ 1 -eq $doubleref ] ; then
							rpm -Uvh "\"${pkg}\"" 2>>"${LOG}"
						else
							rpm -Uvh "${pkg}" 2>>"${LOG}"
						fi
					fi
				
					if [ 0 -eq $? ] ; then
						endInst "sepap-legacy"
					else
						failInst "sepap-legacy"
					fi
				else
					#do not uninstall sepap(-x64) package when fail to load AP modules

					beginInst "sepap-legacy"
					if [ $x64 -eq 1 ] ; then
						dpkg -i "${LEGACY_DIR}/sepap-legacy-amd64.deb" >> ${LOG} 2>&1
					else
						dpkg -i "${LEGACY_DIR}/sepap-legacy.deb" >> ${LOG} 2>&1
					fi

					if [ 0 -eq $? ] ; then
						endInst "sepap-legacy"
					else
						failInst "sepap-legacy"
					fi
				fi

				unset curdir
				if [ -f /etc/init.d/autoprotect ] ; then
					echo "try to start autoprotect again" >> ${LOG}
					/etc/init.d/autoprotect start >> ${LOG} 2>&1
					local symevko=$(/sbin/lsmod | grep -E "^symev" | awk -F' ' '{print $1}' | sed 's/_/\-/g')
					if [ -z "$symevko" ] ; then
						echo "the current kernel `uname -r` is not supported yet" >> ${LOG}
					fi
				else
					echo "autoprotect doesn't exist." >> ${LOG}
				fi
			
				isprecompilesymevreloaded
				if [ $? -eq 1 ] ; then
					compilekernelmodules
				fi
			else
				compilekernelmodules
			fi
		fi
	fi

#remove install configuration file.
	rm -f ${INSTALL_CFG} >> ${LOG} 2>&1
	
	for daemon in ${DAEMONS}
	do
		if [ ! -f /etc/init.d/${daemon} ] ; then
			echo "/etc/init.d/${daemon} doesn't exist, skip enable it." >> ${LOG}
			continue
		fi

		/etc/init.d/${daemon} start >> ${LOG} 2>&1
		if [ ! 0 -eq $? ] ; then
			writeLog "failed to start $daemon ."
		else
			echo "$daemon is started successfully." >> ${LOG}
		fi
	
		#enable ap
		if [ "${daemon}" = "rtvscand" ] ; then
			local symc_dir=$(cat /etc/Symantec.conf | grep BaseDir | awk -F'=' '{print $2}')
			local savtool=${symc_dir}/symantec_antivirus/sav
			if [ -f $savtool ] ; then
				$savtool autoprotect -e >> ${LOG} 2>&1
				local ret=$?
				if [ 0 -eq $ret ] ; then
					echo "Succeed to enable ap" >> ${LOG}
				else
					echo "Failed to enable ap, err: ${ret}" >> ${LOG}
				fi
				local apstatus=$(${savtool} info -a 2>>${LOG})
				echo "AP status: ${apstatus}" >> ${LOG}
			fi
		fi

	done
}

selinuxSupport()
{
	which chcon > /dev/null 2>&1
	if [ ! 0 -eq $? ] ; then
		writeLog "chcon is not installed, skip setting selinux attribute."
		return 0
	fi

	if [ "${PREFIX}" != "" ] ; then
		dir="${PREFIX}/symantec_antivirus"
	else
		dir=/opt/Symantec/symantec_antivirus
	fi

	chcon -R -t texrel_shlib_t $dir >> "${LOG}" 2>&1
	
	return 0
}

InstallDeb()
{
	local ret=0
	IsX64=0
	IsPlatformX64
	if [ 1 -eq $? ] ; then
		IsX64=1
	fi

	local legacypackage
	local additionalpackage

	dpkg -s "savap-legacy" > /dev/null 2>&1
	if [ $? -eq 0 ] ; then
		if [ $IsX64 -eq 1 ] ; then
			additionalpackage="sepap-legacy"
		else
			additionalpackage="sepap-legacy-amd64"
		fi		
		IS_CHECK_LEGACY_PACKAGE=1
	fi

	export curdir="${PACKAGE_DIR}"

	for pa in ${INSTALL_PKG_LIST} ${additionalpackage}
	do
		if [ "${pa}" = "sepap" -a 1 -eq ${IsX64} ] ; then
			package=${pa}-x64.deb
		else
			package=${pa}.deb
		fi

		if [ "${pa}" = "sepap-legacy" -o "${pa}" = "sepap-legacy-amd64" ] ; then
			deb="${LEGACY_DIR}/${package}"
		else
			deb="${PACKAGE_DIR}/${package}"
		fi


		if [ ! -f "$deb" ] ; then
			if [ "${pa}" = "sep" ] ; then
				writeLog "${deb} doesn't exist, install failed."
				ret=1
				break
			else
				writeLog "${deb} package is missing. Skipping ..."
				continue
			fi
		fi

		beginInst "${pa}"
		dpkg -i "$deb" 2>>"${LOG}"

		if [ 0 -eq $? ] ; then
			endInst "${pa}"
			continue
		else
			local errmsg=$(awk '{a[NR]=$0} END{print a[NR=FNR]}' "${LOG}")
			failInst "${pa}" "${errmsg}"
			if [ "${pa}" = "sep" ] ; then
				ret=1
				break
			else
				continue
			fi
		fi
	done

	unset curdir

	return $ret
}

InstallRpm()
{
	local ret=0
	IsX64=0
	IsPlatformX64
	if [ 1 -eq $? ] ; then
		IsX64=1
	fi

	local legacypackage
	local additionalpackage

	if [ $IsX64 -eq 1 ] ; then
		rpm -qa "savap-x64-legacy" | grep "savap-x64-legacy" > /dev/null 2>&1
		if [ $? -eq 0 ] ; then
			additionalpackage="sepap-legacy-x86_64"
			IS_CHECK_LEGACY_PACKAGE=1
		fi
	else
		rpm -qa "savap-legacy" | grep "savap-legacy" > /dev/null 2>&1
		if [ $? -eq 0 ] ; then
			additionalpackage="sepap-legacy"
			IS_CHECK_LEGACY_PACKAGE=1
		fi
	fi

	#export curdir so that rpm scripts can get the current folder.
	export curdir="${PACKAGE_DIR}"

	for pa in ${INSTALL_PKG_LIST} ${additionalpackage}
	do
		# we don't need to check whether existing rpm is installed or not.
		# this should be done by RPM DB and if the rpm is installed before, 
		# upgrade will be performed.
		if [ ${pa} = "sepap" -a 1 -eq ${IsX64} ] ; then
			package=${pa}-x64.rpm
		else
			package=${pa}.rpm
		fi

		if [ "${pa}" = "sepap-legacy" -o "${pa}" = "sepap-legacy-x86_64" ] ; then
			pkg="${LEGACY_DIR}/${package}"
		else
			pkg="${PACKAGE_DIR}/${package}"
		fi

		if [ ! -f "${pkg}" ] ; then
			if [ "${pa}" = "sep" ] ; then
				writeLog "${pkg} doesn't exist, install failed."
				ret=1
				break
			else
				writeLog "${pkg} package is missing. Skipping ..."
				continue
			fi
		fi
		local module=$(echo $package | sed -e 's/sep/sav/g' -e 's/.rpm//g')
		beginInst "${pa}"

		doubleref=0
		rpm -qpi "${pkg}" 2>/dev/null | grep 'Vendor: Symantec Corporation' > /dev/null 2>&1
		if [ ! 0 -eq $? ] ; then
			rpm -qpi "\"${pkg}\"" 2>/dev/null | grep 'Vendor: Symantec Corporation' > /dev/null 2>&1
			if [ 0 -eq $? ] ; then
				doubleref=1
			fi
		fi

		if [ "${PREFIX}" != "" ] ; then
			if [ 1 -eq $doubleref ] ; then
				rpm -Uvh "--prefix=${PREFIX}" "\"${pkg}\"" 2>>"${LOG}"
			else
				rpm -Uvh "--prefix=${PREFIX}" "${pkg}" 2>>"${LOG}"
			fi
		else
			if [ 1 -eq $doubleref ] ; then
				rpm -Uvh "\"${pkg}\"" 2>>"${LOG}"
			else
				rpm -Uvh "${pkg}" 2>>"${LOG}"
			fi
		fi

		if [ 0 -eq $? ] ; then
			endInst "${pa}"
			continue
		else
			local errmsg=$(awk '{a[NR]=$0} END{print a[NR=FNR]}' "${LOG}")
			failInst "${pa}" "${errmsg}"
			if [ "${pa}" = "sep" ] ; then
				ret=1
				break
			else
				continue
			fi
		fi
	done

	unset curdir
	return $ret
}

getOldProductVersion()
{
	if [ -f ${ETC_SYMC}/setup.ini ] ; then
		local FromProduct=$(cat ${ETC_SYMC}/setup.ini | grep ProductVersion | awk -F'=' '{print $2}' | sed -e 's/^ //g' -e 's/\r//g')
		echo $FromProduct
		return 0
	else
		local pkgs="sav savap savjlu"
		IsRpmSupported
		if [ 0 -eq $? ] ; then #rpm not supported.
			for pkg in $pkgs
			do
				local FromProduct=$(dpkg -s $pkg 2>/dev/null | grep Version | awk -F':' '{print $2}' | sed -e 's/ //g' -e 's/-/./g')
				if [ ! "" = "$FromProduct" ] ; then
					echo $FromProduct
					return 0
				fi
			done
		else
			for pkg in $pkgs
			do
				local FromProduct=$(rpm -qa $pkg 2>/dev/null | cut -d '-' -f 2- | sed -e 's/ //g' -e 's/-/./g')
				if [ ! "" = "$FromProduct" ] ; then
					echo $FromProduct
					return 0
				fi
			done
		fi

		echo ""
		return 0
	fi
}

getInstallProductVersion()
{
	if [ -f "${CONFIG}/setup.ini" ] ; then
		local ToProduct=$(cat "${CONFIG}/setup.ini" | grep ProductVersion | awk -F'=' '{print $2}' | sed -e 's/^ //g' -e 's/\r//g')
		echo $ToProduct
		return 0
	fi

	echo ""
	return 0
}

#$1 from build.
#$2 to build.
isNewBuild()
{
	from="$1"
	to="$2"

	if [ "${from}" = "" ] ; then #fresh install
		return 1
	fi
	old_maj=$(echo $from | awk -F'.' '{print $1}')
	old_min=$(echo $from | awk -F'.' '{print $2}')
	old_sub=$(echo $from | awk -F'.' '{print $3}')
	old_build=$(echo $from | awk -F'.' '{print $4}')

	new_maj=$(echo $to | awk -F'.' '{print $1}')
	new_min=$(echo $to | awk -F'.' '{print $2}')
	new_sub=$(echo $to | awk -F'.' '{print $3}')
	new_build=$(echo $to | awk -F'.' '{print $4}')

	if [ "" = "${old_maj}" ] ; then 
		return 1
	elif [ "" = "${new_maj}" ] ; then
		return 0
	fi

	if [ ${old_maj} -lt ${new_maj} ] ; then
		return 1
	elif [ ${old_maj} -gt ${new_maj} ] ; then
		return 0
	fi

	#$old_maj=$new_maj
	if [ "" = "${old_min}" ] ; then
		return 1
	elif [ "" = "${new_min}" ] ; then
		return 0
	fi

	if [ ${old_min} -lt ${new_min} ] ; then
		return 1
	elif [ ${old_min} -gt ${new_min} ] ; then
		return 0
	fi

	#$old_min=$new_min
	if [ "" = "${old_sub}" ] ; then
		return 1
	elif [ "" = "${new_sub}" ] ; then
		return 0
	fi

	if [ ${old_sub} -lt ${new_sub} ] ; then
		return 1
	elif [ ${old_sub} -gt ${new_sub} ] ; then
		return 0
	fi

	#$old_sub=$new_sub
	if [ ${old_build} -lt ${new_build} ] ; then
		return 1
	else #$old_build >= $new_build
		return 0
	fi
}

install()
{
	local ret=0

	writeLog "Starting to install Symantec Endpoint Protection for Linux"
	
	#try to get old product version.
	local former_build=$(getOldProductVersion)
	local current_build=$(getInstallProductVersion)
	if [ "${current_build}" = "" ] ; then
		writeLog "Cannot complete installation. setup.ini is missing."
		return 1
	fi
	echo "FromProduct=${former_build}" >> ${LOG}
	echo "ToProduct=${current_build}" >> ${LOG}

	#check version first, make sure not downgrade
	isNewBuild "${former_build}" "${current_build}"
	local isnewer=$?
	if [ $isnewer -eq 0 ] ; then
		writeLog "Downgrade is not supported. Please make sure the target version is newer than the original one."
		return 1
	fi
    
	export curdir="${PACKAGE_DIR}"
	preCheckEnv "all" "${PREFIX}"
	ret=$?
	unset curdir

	if [ $ret -ne 0 ] ; then
		writeLog "Pre-check failed."
		return 1
	fi

	#first set flag to disable dameons during the installation.
	disableDaemon

	if [ ! "" = "${former_build}" ] ; then
		preInst "${former_build}"
	fi

	IsRpmSupported
	if [ 0 -eq $? ] ; then
		InstallDeb
		ret=$?
	else
		InstallRpm
		ret=$?
	fi

	#exit when the packages are not installed successfully
	if [ ! 0 -eq $ret ] ; then
		return $ret
	fi

	#set selinux attributes for savfl folders.
	selinuxSupport

	#copy SyLink.xml, then install rpm or deb.
	CopyCfg "${former_build}" "${current_build}"

	#start daemons after install.
	enableDaemon

	#make modprobe -l symap* and modprobe -l symev* work fine.
	depmodkernel
	
	if [ ! "" = "${former_build}" ] ; then
		postInst "${former_build}"
	fi

	writeLog "Installation completed"

	return $ret
}

UninstallDeb()
{
	num=${#PACKAGE_LIST[@]}
	local failnum=0
	for ((i=1; i<=${num};i++));
	do
		idx=$(($num - $i))
		pa=${PACKAGE_LIST[$idx]}

		dpkg -s ${pa} > /dev/null 2>&1
		if [ ! 0 -eq $? ] ; then
			echo "${pa} has not been installed yet." >> ${LOG}
			continue
		fi

		beginRm "${pa}"
		dpkg -P ${pa} | tee -a "${LOG}"
		if [ 0 -eq $? ] ; then
			endRm "${pa}"
			continue
		fi

		failRm "${pa}" "$?"
		failnum=$((failnum +1))
	done

	if [ $failnum -eq 0 ] ; then
		echo "Perform post uninstall operations." >> ${LOG}
		postrm
		echo "Post uninstall operations finished." >> ${LOG}
	fi

	return 0
}

UninstallRpm()
{
	local num
	local isX64=0
	IsPlatformX64
	isX64=$?
	if [ ${isX64} -eq 1 ] ; then
		#x86_64
		num=${#PACKAGE_LIST_X64[@]}
	else
		#i386
		num=${#PACKAGE_LIST[@]}
	fi

	local failnum=0
	for ((i=1;i<=${num};i++))
	do
		idx=$(($num - $i))

		if [ ${isX64} -eq 1 ] ; then
			#x86_64
			pa=${PACKAGE_LIST_X64[$idx]}
		else
			#i386
			pa=${PACKAGE_LIST[$idx]}
		fi

		rpm -qa ${pa} | grep ${pa} > /dev/null 2>&1
		if [ 0 -eq $? ] ; then
			beginRm "${pa}"
			rpm -e ${pa} | tee -a "${LOG}"
			if [ 0 -eq $? ] ; then
				endRm "${pa}"
			else
				failRm "${pa}" "$?"
				failnum=$((failnum + 1))
			fi
		else
			echo "The package ${pa} has not been installed yet." >> ${LOG}
		fi
	done

	if [ $failnum -eq 0 ] ; then
		echo "Perform post uninstall operations" >> ${LOG}
		postrm
		echo "Post uninstall operations finished" >> ${LOG} 
	fi

	return 0
}

postrm()
{
	#remove unnecessary files.
# defect 3407299. The /etc/Symantec.conf file may also remain for other Symantec product may use it (MR14 Impl.pdf)
	#rmfiles="/etc/Symantec.conf"
	#for file in $rmfiles
	#do
	#	if [ -f "$file" ] ; then
	#		rm -f "$file" >> ${LOG} 2>&1
	#	fi
	#done

	#remove avdefs group.
	groupdel avdefs >> ${LOG} 2>&1

	#remove some the remaining folders
	local basedir=$(getBaseDir)
	if [ "${basedir}" = "" ] ; then
		basedir="/opt/Symantec"
	fi

	if [ -d "${basedir}/virusdefs" ] ; then
		rm -rf "${basedir}/virusdefs"
	fi
}

prerm()
{
	#remove soft link of kernel drivers under /lib/modules/kernelversion/kernel/drivers/char
	local kerneldir="/lib/modules/$(uname -r)/kernel/drivers/char"
	local symap=$(ls $kerneldir/symap* 2>/dev/null | xargs)
	local symev=$(ls $kerneldir/symev* 2>/dev/null | xargs)

	for ap in $symap
	do
		echo "remove $ap" >> "${LOG}"
		rm -f $ap >> "${LOG}" 2>&1
	done

	for ev in $symev
	do
		echo "remove $ev" >> "${LOG}"
		rm -f $ev >> "${LOG}" 2>&1
	done
}

uninstall()
{
	local retval=0
	echo "Starting to uninstall Symantec Endpoint Protection for Linux."
	echo "$(date): Starting to uninstall Symantec Endpoint Protection for Linux." >> "${LOG}"

	prerm
	IsRpmSupported

	if [ 0 -eq $? ] ; then
		UninstallDeb
		retval=$?
	else
		UninstallRpm
		retval=$?
	fi

	echo "Uninstall completed"
	echo "$(date): Uninstall completed" >> "${LOG}"

	setSplit
	writeLog "The log files for uninstallation of Symantec Endpoint Protection for Linux are under ~/:"
	local logfiles="sepfl-install.log\
					sep-install.log\
					sepap-install.log\
					sepap-legacy-install.log\
					sepui-install.log\
					sepjlu-install.log\
					"

	for logfile in $logfiles
	do
		writeLog "${logfile}"
	done

	return $retval
}

usage()
{
	echo "Usage: install.sh [options]
the options are:
		-i install SEP for Linux.
		-u uninstall SEP for Linux.
		--prefix <dir> install to alternate location if <dir> exists. Note, this option is only for RPM package.
		"
	return 0
}

checkRunningEnv()
{
	local owner=$(whoami)
	local super=$(cat /etc/passwd | awk -F':' '($1 == "'$owner'") && ($3 == 0) {print $1}')
	if [ "$owner" != "$super" ] ; then
		writeLog "You are logged on as $owner. Log off, log on again as a superuser, and try again."
		return 1
	fi

	return 0
}

setSplit()
{
	writeLog "============================================================="
}

getBaseDir()
{
	if [ ! -f /etc/Symantec.conf ] ; then
		echo ""
		return 1
	fi

	local dir=$(cat /etc/Symantec.conf | grep BaseDir | awk -F'=' '{print $2}')
	echo $dir
	return 0
}

postCheck()
{
	setSplit
	writeLog "Daemon status:"
	for daemon in ${DAEMONS}
	do
		local status=""
		if [ ! -f /etc/init.d/${daemon} ] ; then
			status="not enabled"
		else
			status=$(/etc/init.d/${daemon} status 2>/dev/null)
			if [ 0 -eq $? ] ; then
				status="running"
			else
				status="stopped"
			fi
		fi

		if [ "smcd" = "${daemon}" -o "symcfgd" = "${daemon}" ] ; then
			writeLog "${daemon}\t\t\t\t[${status}]"
		else
			writeLog "${daemon}\t\t\t[${status}]"
		fi
	done

	setSplit
	local lsmodtool=/bin/lsmod
	if [ ! -f $lsmodtool ] ; then
		lsmodtool=/sbin/lsmod
	fi
	local drivers=$($lsmodtool | grep symap | awk -F' ' '{print $1}')
	if [ ! "" = "${drivers}" ] ; then
		writeLog "Drivers loaded:"
		writeLog "${drivers}"
	else
		writeLog "Error: No drivers are loaded into kernel."
	fi

	setSplit
	local basedir=$(getBaseDir)
	local sav=${basedir}/symantec_antivirus/sav
	local apstatus=$(${sav} info -a 2>>${LOG})
	writeLog "Auto-Protect starting"
	for ((i=1; i<=10; i++))
	do
		echo "AP status: ${apstatus} in ${i} time." >> ${LOG}
		local needwait=0
		if [ "" = "${apstatus}" ] ; then
			needwait=1
		elif [ "Disabled" = "${apstatus}" ] ; then
			needwait=1
		else
			needwait=0
		fi

		if [ 0 -eq $needwait ] ; then
			break
		fi

		sleep 2s
		apstatus=$(${sav} info -a 2>>${LOG})		
	done
	local defstatus=$(${sav} info -d 2>>${LOG})
	writeLog "Protection status:"
	writeLog "Definition:\t${defstatus}"
	writeLog "AP:\t\t${apstatus}"

	setSplit
	writeLog "The log files for installation of Symantec Endpoint Protection for Linux are under ~/:"
	local logfiles="sepfl-install.log\
					sep-install.log\
					sepap-install.log\
					sepap-legacy-install.log\
					sepui-install.log\
					sepjlu-install.log\
					sepfl-kbuild.log\
					"

	for logfile in $logfiles
	do
		writeLog "${logfile}"
	done
}

#operations before install is started.
#$1 from_build which is used to check whether upgrade from MR14 or before.
preInst()
{
	local isRpm=0
	IsRpmSupported
	if [ 1 -eq $? ] ; then
		isRpm=1
	fi

	#perform check for presence of only sepap-legacy
	#in which case, we need to remove this package for upgrade.
	#since sepap-legacy package in ferrari conflicts with sepap package in porche
	local savapName=${PACKAGE_LIST[1]}
	local savapLegacyName=${PACKAGE_LIST[2]}

	IsPlatformX64
	if [ $? -eq 1 -a 1 -eq ${isRpm} ] ; then
		savapName=${PACKAGE_LIST_X64[1]}
		savapLegacyName=${PACKAGE_LIST_X64[2]}		
	fi

	if [ 0 -eq ${isRpm} ] ; then
		dpkg -s $savapName > /dev/null 2>&1
		if [ ! 0 -eq $? ] ; then
			dpkg -s $savapLegacyName > /dev/null 2>&1
			if [ 0 -eq $? ] ; then
				beginRm "${savapLegacyName}"
				prerm
				dpkg -P ${savapLegacyName} | tee -a "${LOG}"
				if [ 0 -eq $? ] ; then
					endRm "${savapLegacyName}"
				else
					failRm "${savapLegacyName}" "$?"
				fi
			fi
		fi
	else
		rpm -qa ${savapName} | grep ${savapName} > /dev/null 2>&1
		if [ ! 0 -eq $? ] ; then
			rpm -qa ${savapLegacyName} | grep ${savapLegacyName} > /dev/null 2>&1
			if [ 0 -eq $? ] ; then
				beginRm "${savapLegacyName}"
				prerm
				rpm -e ${savapLegacyName} | tee -a "${LOG}"
				if [ 0 -eq $? ] ; then
					endRm "${savapLegacyName}"
				else
					failRm "${savapLegacyName}" "$?"
				fi
			fi
		fi
	fi

	isNewBuild "1.0.14.999" "$1"
	if [ 1 -eq $? ] ; then #not upgrade from 1.0.14 or before.
		echo "from $1, not upgrade from 1.0.14 or before" >> "${LOG}"
		return 0
	fi

	if [ 1 -eq ${isRpm} ] ; then #perform rpm check for savjlu.
		rpm -q "savjlu" >> "${LOG}" 2>&1
		if [ 0 -eq $? ] ; then
			echo "remove old savjlu: $1 first." >> "${LOG}"
			rpm -e "savjlu" >> "${LOG}"
			if [ 0 -eq $? ] ; then
				echo "succeeded to remove old savjlu: $1" >> "${LOG}"
			else
				echo "failed to remove old savjlu: $1, err: $?" >> "${LOG}"
			fi
		fi
	else
		dpkg -s "savjlu" >> "${LOG}" 2>&1
		if [ 0 -eq $? ] ; then
			echo "remove old savjlu: $1 first." >> "${LOG}"
			dpkg -P "savjlu" >> "${LOG}"
			if [ 0 -eq $? ] ; then
				echo "succeeded to remove old savjlu: $1" >> "${LOG}"
			else
				echo "failed to remove old savjlu: $1, err: $?" >> "${LOG}"
			fi
		fi
	fi

	return 0
}

depmodkernel()
{
	local apdir="$(getBaseDir)/autoprotect"
	local kerneldir="/lib/modules/$(uname -r)/kernel/drivers/char"
	local symev=$(/sbin/lsmod | grep -e "^symev" | awk -F' ' '{print $1}')
	local symap=$(/sbin/lsmod | grep -e "^symap" | awk -F' ' '{print $1}')

	if [ "$symev" = "" ] ; then
		echo "kernel drivers are not loaded." >> "${LOG}"
		return 0
	fi

	if [ -f $kerneldir/$symev.ko ] ; then
		rm -f $kerneldir/$symev.ko >> "${LOG}" 2>&1
	fi

	if [ -f $kerneldir/$symap.ko ] ; then
		rm -f $kerneldir/$symap.ko >> "${LOG}" 2>&1
	fi

	pushd $apdir >> "${LOG}" 2>&1
	local evfiles=$(ls symev* | xargs)
	for ev in $evfiles
	do
		local tempevfile=$(echo $ev | sed -e 's/\.ko//g' -e 's/\./-/g' -e 's/_/-/g')
		local tempev=$(echo $symev | sed -e 's/\./-/g' -e 's/_/-/g')
		if [ "$tempev" = "$tempevfile" ] ; then
			ln -s $apdir/$ev $kerneldir/$symev.ko >> "${LOG}" 2>&1
			if [ 0 -eq $? ] ; then
				echo "succeed to make link $kerneldir/$symev.ko" >> "${LOG}"
			else
				echo "failed to make link $kerneldir/symev.ko , err: $?" >> "${LOG}"
			fi
			break
		fi
	done

	if [ "$symap" = "" ] ; then
		echo "symap is not loaded." >> "${LOG}"
		popd >> "${LOG}" 2>&1
		return 0
	fi

	local apfiles=$(ls symap* | xargs)
	for ap in $apfiles
	do
		local tempapfile=$(echo $ap | sed -e 's/\.ko//g' -e 's/\./-/g' -e 's/_/-/g')
		local tempap=$(echo $symap | sed -e 's/\./-/g' -e 's/_/-/g')
		if [ "$tempapfile" = "$tempap" ] ; then
			ln -s $apdir/$ap $kerneldir/$symap.ko >> "${LOG}" 2>&1
			if [ 0 -eq $? ] ; then
				echo "succeed to make link $kerneldir/$symap.ko" >> "${LOG}"
			else
				echo "failed to make link $kerneldir/$symap.ko, err: $?" >> "${LOG}"
			fi

			break
		fi
	done

	/sbin/depmod -A >> "${LOG}" 2>&1

	popd >> "${LOG}" 2>&1
	return 0
}

#operations after install is finished.
#$1 from_build which is used to check whether upgrade from MR14 or before.
#1. check whether savreporter is installed, if so, remove it.
postInst()
{
	isNewBuild "1.0.14.999" "$1"
	if [ 1 -eq $? ] ; then #not upgrade from 1.0.14 or before.
		echo "from $1, not upgrade from 1.0.14 or before." >> "${LOG}"
		return 0
	fi

	IsRpmSupported
	if [ 1 -eq $? ] ; then #perform rpm check for savreporter.
		rpm -q "$SAVREPORTER" >> "${LOG}" 2>&1
		if [ 0 -eq $? ] ; then
			echo "found $SAVREPORTER, need to remove it." >> "${LOG}"
			rpm -e "$SAVREPORTER" >> "${LOG}" 2>&1
			if [ 0 -eq $? ] ; then
				echo "succeeded to remove $SAVREPORTER" >> "${LOG}"
			else
				echo "failed to remove $SAVREPORTER, err: $?" >> "${LOG}"
			fi
		fi
	else
		dpkg -s "$SAVREPORTER" >> "${LOG}" 2>&1
		if [ 0 -eq $? ] ; then
			echo "found $SAVREPORTER, need to remove it." >> "${LOG}"
			dpkg -P "$SAVREPORTER" >> "${LOG}" 2>&1
			if [ 0 -eq $? ] ; then
				echo "succeeded to remove $SAVREPORTER" >> "${LOG}"
			else
				echo "failed to remove $SAVREPORTER" >> "${LOG}"
			fi
		fi
	fi

	return 0
}


## main() starts here:

if [ "$1" = "" ] ; then
	usage
	exit 1
fi

while [ "$1" != "" ] ; 
do
	case $1 in
		-h | --help)	usage
						exit 0
						;;
		-i)				export IS_INSTALL=1
						;;
		-u)				export IS_UNINSTALL=1
						;;
		--prefix)		shift ; export PREFIX=$1
						;;
		--precheck)		IS_PRECHECK=1 ; shift ; PRECHECK_PACKAGE_NAME=$1 ; shift ; PREFIX="$1"
						;;
		*)				usage
						exit 1
						;;
		esac
		shift
done

if [ 0 -eq ${IS_PRECHECK} ] ; then 
	#normal installation
	# Rename logfile if already exists, use pid for extension
	if [ -f ${LOG} ] ; then
		mv -f ${LOG} ${LOG}.$$
	fi

	checkRunningEnv
	if [ 0 -ne $? ] ; then
		exit 1
	fi

	ret=0

	if [ 1 -eq ${IS_INSTALL} ] ; then
		if [ -f "${PRECHECK_CFG}" ] ; then
			rm -f "${PRECHECK_CFG}" >> ${LOG} 2>&1
		fi

		install

		ret=$?

		if [ -f "${PRECHECK_CFG}" ] ; then
			rm -f "${PRECHECK_CFG}" >> ${LOG} 2>&1
		fi

		if [ -f "${INSTALL_DATA}" ] ; then
			rm -f "${INSTALL_DATA}" >> ${LOG} 2>&1
		fi

		if [ 0 -eq ${ret} ] ; then
			postCheck
		fi

	elif [ 1 -eq ${IS_UNINSTALL} ] ; then
		uninstall
		ret=$?
	fi
else
	#precheck for specified package and --prefix folder
	preCheckEnv ${PRECHECK_PACKAGE_NAME} "${PREFIX}"
	ret=$?
fi

exit ${ret}
